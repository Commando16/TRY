class SemesterStudents
{

	// subject codes static

	// marks 

}

public class Test
{

	public static void main( String args[] )
	{

		SemesterStudents obj = new SemesterStudents(); 
	
		


	} 

}
