
class LearningClass
{
	public static String A ="hey....i am Static variable...basically an extrovert....i am avilable to everyone.\n";	// it's a static variable



	public String B = "oh.....sorry....i am little introvert ......i can only available in my instance.\n";		// it's a instance variable 
	


	public LearningClass()		// it's a constructor
	{
		System.out.println("hey i am bin bulaya mehmaan\n");
	}


	public void simpleMessage()	// it's a non-static / instance method
	{
		System.out.println("Did you call me......well i am a non-static method of LearningClass class. u can call me instance method...\n");
	}


	public static void anotherMessage()	// it's a static method 
	{
		System.out.println("u can call me with class name or instance/object name, it dosen't matter to me....I am static method\n");	
	}



	// all the components mension above are the major and primary component of a class. there are few more but the are secondary. 
}


public class Test
{
	public static void main( String []args)
	{
		LearningClass obj = new LearningClass();

		System.out.println(  LearningClass.A 	);
		System.out.println(  obj.B  );

		LearningClass.anotherMessage();
		obj.simpleMessage();

	}

}
