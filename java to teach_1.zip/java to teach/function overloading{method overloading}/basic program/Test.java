
class LearningOverloading
{
	public void func()
	{	
		System.out.println( "hey hi... i am function with no argument\n" );	
	}	

	public void func( String name)
	{
		System.out.printf( "hello...%s I can say ur name.\n\n", name );
	}
	
	public void func( String name,  int age)
	{
		System.out.printf( "hello ... %s i can say ur name and age too . It's %d\n\n", name, age );
	}
	
	public void func( int age, String name )
	{
		System.out.printf("hello...%s i can also say ur name and age(%d) but the difference between the previous function and  me is I am asking  for age first then name...\n\n", name, age);
	}
	 
}


public class Test
{
	public static void main( String []args)
	{
		LearningOverloading obj = new LearningOverloading();
		obj.func();
		obj.func("Aman");
		obj.func("Aman", 19);
		obj.func(19, "Aman");
	}

}
